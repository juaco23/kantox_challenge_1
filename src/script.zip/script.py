import base64
import logging
import os
import boto3
from botocore.exceptions import ClientError

AWS_REGION = os.environ['AWS_REGION']
S3_BUCKET = os.environ['S3_BUCKET']
OBJECT_KEY = os.environ['OBJECT_KEY']
KEY_ALIAS = os.environ['KEY_ALIAS']
SECRET_ARN = os.environ['SECRET_ARN']


# logger config
logger = logging.getLogger()
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s: %(levelname)s: %(message)s')

s3_client = boto3.client("s3", region_name=AWS_REGION)
kms_client = boto3.client("kms", region_name=AWS_REGION)
secretsmanager_client = boto3.client('secretsmanager')


def lambda_handler(event, context):
    file_content = s3_client.get_object(Bucket=S3_BUCKET, Key=OBJECT_KEY)["Body"].read()
    try:
        plain_text = kms_client.decrypt(KeyId=KEY_ALIAS,
                                            CiphertextBlob=bytes(
                                                base64.b64decode(file_content)))
    except ClientError:
            logger.exception('Could not decrypt the string.')
            raise
    else:
        my_secret = plain_text['Plaintext'].decode('utf-8')
        response = secretsmanager_client.put_secret_value( SecretId=SECRET_ARN,  SecretString=my_secret)
        print("Your secret: " + response["Name"] + " was updated successfully" )
        

lambda_handler(S3_BUCKET, OBJECT_KEY )